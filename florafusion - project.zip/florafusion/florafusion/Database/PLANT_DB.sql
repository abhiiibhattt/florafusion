SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `plant1`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
    `Uid` INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    `username` VARCHAR(50) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `pswd` VARCHAR(255) NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`,`email`,`pswd`) VALUES
('Aishwarya Shinde','aishwaryashinde@gmail.com','Aishwarya@123'),
('Smruthi Juanita','smruthijuanita@gmail.com','Smruthi@123'),
('Tavidisetty Aishwarya','tav@gmail.com','Tav@123');

CREATE TABLE `Plants` (
    `ProductID` INT(11) NOT NULL AUTO_INCREMENT,
    `Name` VARCHAR(255) NOT NULL,
    `ImageURL` VARCHAR(255),
    `Price` DECIMAL(10,2) NOT NULL,
    `rrp` decimal(10,2) NOT NULL DEFAULT '0.00',
    `quantity` int(11) NOT NULL,
    `Link` VARCHAR(255),
    `Description` TEXT NOT NULL,
    PRIMARY KEY (`ProductID`)
)ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `Plants`(`ProductID`, `Name`, `ImageURL`, `Price`, `rrp`, `quantity`, `Link`,`Description`) VALUES
(1, 'English Ivy', 'https://pilun.co/wp-content/uploads/2022/06/il_794xN.2965360472_f5ne.webp', 450, 0.00, 50, 'Englishivy.html', 'Beautiful and easy-to-grow ivy plant.'),
(2, 'Money Plant', 'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcStOM54J-m1Ncc2TT48ljVPZycbIIKgYppZV3e7UodMr8JvWe7_', 400, 0.00, 50, 'Moneyplant.html', 'Lucky and low-maintenance money plant.'),
(3, 'Orchids', 'https://i.pinimg.com/564x/42/d1/67/42d167e752cc55e8a500f878a4f7b718.jpg', 120, 0.00, 50, 'orchid.html', 'Exotic and elegant orchid blooms.'),
(4, 'Bunny Ear Cactus', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1op-EuCo5vyQYDrFzjdfvk41k0X2eZkl59UHBhwVbqW6AsZwp', 230, 0.00, 50, 'bunnyear.html', 'Adorable and prickly cactus variety.'),
(5, 'Aloe Vera', 'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSu3BYLjpZ9W_cno_d97JhVajN2hgVkSsiKsWHiXClVWJbfn8tm', 120, 0.00, 50,  'aloevera.html', 'Versatile and medicinal aloe vera plant.'),
(6, 'Star Cactus', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2MBRLmYj10A_FQ0cUS6byggQIuBnspeiC_mn3HDzUMHZnSW9f', 170, 0.00, 50,'starcactus.html', 'Unique and compact star-shaped cactus.'),
(7, 'Dumb Care', 'https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcRjh-ovtZ0_DMcvk4VlGSfJjHfNYfVXpTWHMcN04AG4B2j1sy2R', 230, 0.00, 50, 'single-product.html', 'Attractive and air-purifying dumb cane plant.'),
(8, 'Dracaena', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSD8wfojVLJLHMf8mPRz6aZlRxw4bP3-l17Nqg6xB_dVAjaaT31', 300, 0.00, 50, 'Dracaena.html', 'Dramatic and easy-to-care-for dracaena plant.'),
(9, 'Sugarcane', 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcQh9wmdFIcYyHcDpPLQGTVIKN7iDz5Uhn7se5-L6aKmP2coblSc', 200, 0.00, 50, 'sugarcane.html', 'Tropical and sweet sugarcane plant.');


CREATE TABLE `services` (
    `Uid` INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    `firstname` VARCHAR(50) NOT NULL,
    `lastname` VARCHAR(50) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `phoneno` INT(10) NOT NULL,
    `service` VARCHAR(100) NOT NULL,
    `date` DATE NOT NULL,
    `time` TIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Dumping data for table `services`
--

INSERT INTO `services` (`firstname`, `lastname`, `email`, `phoneno`, `service`, `date`, `time`)
VALUES
('John', 'Doe', 'johndoe@example.com', 1234567890, 'Service A', '2024-04-02', '12:00:00'),
('Jane', 'Smith', 'janesmith@example.com', 9876543210, 'Service B', '2024-04-03', '15:30:00');

CREATE TABLE `event` (
    `Uid` INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    `firstname` VARCHAR(50) NOT NULL,
    `lastname` VARCHAR(50) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `phoneno` INT(10) NOT NULL,
    `event` VARCHAR(100) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Dumping data for table `services`
--

INSERT INTO `event` (`firstname`, `lastname`, `email`, `phoneno`, `event`)
VALUES
('John', 'Doe', 'johndoe@example.com', 1234567890, 'Event A'),
('Jane', 'Smith', 'janesmith@example.com', 9876543210, 'Event B');

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Hanging Plants'),
(2, 'Cactus'),
(3, 'Flowering Plants');

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`,`ProductID`, `quantity`) VALUES
(6, 5, 1),
(10, 2, 1);

ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

CREATE TABLE `coupon` (
  `id` int(11) NOT NULL,
  `coupon_code` varchar(20) NOT NULL,
  `coupon_type` varchar(20) NOT NULL,
  `coupon_value` int(11) NOT NULL,
  `cart_min_value` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coupon`
--

INSERT INTO `coupon` (`id`, `coupon_code`, `coupon_type`, `coupon_value`, `cart_min_value`, `status`) VALUES
(1, 'MAX50', 'FLAT OFF', 50, 349, 1),
(2, '15PER', 'DISCOUNT', 15, 399, 1),
(3, 'CELBRT150', 'FLAT OFF', 150, 999, 1),
(4, 'GRAB25', 'DISCOUNT', 25, 299, 1),
(5, 'TRYNEW','DISCOUNT', 20, 399, 1);

-- --------------------------------------------------------
CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `ProductID`, `quantity`) VALUES
(48, '6078334fb2ae4', 2, 2),
(49, '6078334fb2ae4', 3, 1),
(50, '6078334fb2ae4', 5, 1),
(53, '60784750591a7', 16, 2),
(54, '607938f0a2073', 7, 1),
(55, '607938f0a2073', 11, 1);

--
-- Table structure for table `order_track`
--

CREATE TABLE `order_track` (
  `id` varchar(255) NOT NULL,
  `order_date` datetime NOT NULL,
  `order_total` int(11) NOT NULL,
  `coupon` varchar(100) NOT NULL,
  `address` int(11) NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `payment_status` varchar(100) NOT NULL,
  `order_status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_track`
--

INSERT INTO `order_track` (`id`, `order_date`, `order_total`, `coupon`, `address`, `payment_mode`, `payment_status`, `order_status`) VALUES
('6078334fb2ae4', '2021-04-15 06:06:31', 490, '15PER', 9, 'COD', 'Paid', 'Purchased'),
('607938f0a2073', '2021-04-16 12:42:48', 540, '15PER', 9, 'Amazon pay', 'Paid', 'Purchased');


CREATE TABLE `checkout` (
    `Uid` INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    `firstname` VARCHAR(50) NOT NULL,
    `lastname` VARCHAR(50) NOT NULL,
    `country` VARCHAR(50) NOT NULL,
    `address` VARCHAR(50) NOT NULL,
    `city` VARCHAR(50) NOT NULL,
    `state` VARCHAR(50) NOT NULL,
    `zip` INT(6) NOT NULL,
    `phoneno` INT(10) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `ordernote` VARCHAR(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `checkout` (`firstname`, `lastname`, `country`, `address`, `city`, `state`, `zip`, `phoneno`, `email`, `ordernote`)
VALUES
('Shinde', 'Rajkumar', 'India', 'Basavannagudi', 'Bengaluru', 'Karnataka', 560029, 9834567890, 'shinde@email.com', 'Good service'),
('Smruthi', 'Juanita', 'India', 'BTM', 'Bengaluru', 'Karnataka', 560056, 9234567890, 'smruthi@email.com', 'Good service');

-- Table structure for table `contact`
CREATE TABLE `contact` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `firstname` VARCHAR(50) NOT NULL,
    `email` VARCHAR(50) NOT NULL,
    `phoneno` VARCHAR(15) NOT NULL,
    `subject` VARCHAR(100) NOT NULL,
    `message` TEXT NOT NULL,
    `submission_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `contact` (`firstname`, `email`, `phoneno`, `subject`, `message`)
VALUES
('John', 'johndoe@example.com', '1234567890', 'prices', 'great service!!'),
('Jane', 'janesmith@example.com', '9876543210', 'prices', 'great service!!');


CREATE TABLE `faq` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `firstname` VARCHAR(50) NOT NULL,
    `email` VARCHAR(50) NOT NULL,
    `phoneno` VARCHAR(15) NOT NULL,
    `subject` VARCHAR(100) NOT NULL,
    `message` TEXT NOT NULL,
    `submission_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `faq` (`firstname`, `email`, `phoneno`, `subject`, `message`)
VALUES
('John', 'johndoe@example.com', '1234567890', 'prices', 'great service!!'),
('Jane', 'janesmith@example.com', '9876543210', 'prices', 'great service!!');


ALTER TABLE `coupon`
  ADD PRIMARY KEY (`id`);
-- --------------------------------------------------------
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `order_track`
  ADD PRIMARY KEY (`id`);
-- --------------------------------------------------------
ALTER TABLE `coupon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

  ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;