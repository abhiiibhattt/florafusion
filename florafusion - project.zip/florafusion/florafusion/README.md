# PlantLover-HTML-Template

GET PRO HERE:
https://templatesjungle.gumroad.com/l/plantlover-bootstrap-html-template

It is a HTML CSS template by TemplatesJungle.com - https://templatesjungle.com/
You can use this template as a starter template and start building as you require.

The code is consistent and can be easily maintained as we have followed a good coding standards. We want everyone to easily understand it and modify it according to their requirement. As the main goal of providing these templates is to give you something to work on before even starting.


FREE FOR BOTH PERSONAL AND COMMERCIAL USE

This HTML Template is provided by TemplatesJungle.com and is free to use in both personal and commercial projects.


RIGHTS

You are allowed to use it in your personal projects and commercial projects.

You can modify and sell it to your clients.


PROHIBITIONS

You are not permitted to resell or redistribute (paid or free) as it is. 

You cannot use it to build premium templates, themes or any other goods to be sold on marketplaces.

If you want to share the resource in your blog, you must point it to original TemplatesJungle.com resource page. 

You cannot host the download file in your website.


SUPPORT

You can contact us to report any bugs and errors in the template. We will try and fix them immediately although it's a free resource.

Feel free to let us know about what you want to see in the future downloads. We will definitely give it a thought while creating our next freebie.

support@templatesjungle.com

CREDITS & REFERENCES

https://getbootstrap.com/

Stock Photos
https://unsplash.com/
https://www.freepik.com/
https://www.pexels.com/

Fonts
Google fonts
https://fonts.google.com/

Icons
https://icomoon.io/

JQuery Plugins

StellarNav - https://github.com/vinnymoreira/stellarnav
Swiper Slider - https://swiperjs.com/
Slick Slider - https://kenwheeler.github.io/slick/
Chocolat.js – a Free Lightbox Plugin -http://chocolat.insipi.de/
Magnific Lightbox - https://github.com/dimsemenov/Magnific-Popup

Thanks for downloading from TemplatesJungle.com !

# Institute-of-Cambridge---Group2---Project-Report
The “Institute of Cambridge” Website (web based application) is useful for the students, faculty, guest who likes to display result as well schedules of examination and all that task like event, news, students can find out list of fresh courses offered by them and admission procedure, discussion forum, fee structure etc. without going to institute. It provides the facility to the students or guest to have complete information about the institute.

@@@@@ HOW TO RUN THIS PROJECT @@@@@

Step 1: Download XAMPP in your system (Windows / Linux) ( Link: https://www.apachefriends.org/download.html )

Step 2: Run XAMPP Module (Apache & MySQL)

Step 3: Open browser and enter in URL "localhost/assignment" without quote.

Step 4: Create a Datebase named "icsnew" without quote.

Step 5: Import "ICS_DB.sql" File into database you just created. (you we'll find that file in Database/ folder above code.

Step 6: Copy & Paste all file listed above into htdocs by creating a separate folder.

Step 7: Open Browser and enter in URL bar "localhost/<folder_name>" without quotes.

Done!

if you still need help. don't shy to ask, I'll happy to help you.

Email: xyz@outlook.com



