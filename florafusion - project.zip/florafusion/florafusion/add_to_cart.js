
// we need to write an ajax call of jquery so that the particular item gets added to the cart table in the db 
//at backend, without refreshing the page

$(document).ready(function(){
	$('.add_the_plant').click(function(){
		var product_id = $(this).data('product-id');
		$.ajax({
			url:"add_to_cart.php?product_id="+product_id,
			success:function(data){
				alert(data);
			}
		});
	});
});
function addToCart(product_id) {
	// Redirect to the designated page with the product ID
	window.location.href = 'cart.php?product_id=' +product_id;
  }
  