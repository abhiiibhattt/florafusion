<?php
require "database.php"; // Include the database connection file

session_start();

// Check if the product ID is received
if (isset($_POST['productId'])) {
    // Retrieve the product ID from the POST data
    $productId = $_POST['productId'];

    // Perform database connection (assuming it's handled in database.php)
    $conn = mysqli_connect("localhost", "root", "", "plant5");

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

	// Check if the product already exists in the cart
	$query ="SELECT * FROM cart WHERE ProductID = '$productId'";

	$result = mysqli_query($conn, $query);

	if (mysqli_num_rows($result) > 0) {
		echo "This product already exists in your cart";
		exit();
	}

	// Insert the values into the database if the product doesn't exist in the cart
    $query1 = "INSERT INTO cart (ProductID, quantity) VALUES ('$productId', 1)";

    // Execute the query
    if (mysqli_query($conn, $query1)) {
        // Product added successfully
        echo 'Product added to cart';
    } else {
        // Failed to add product
        echo 'Some error occurred! Please try again.';
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    // Product ID not received
    echo 'error';
}
?>
