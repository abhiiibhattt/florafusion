$(document).ready(function(){

    var id, current_quantity, new_quantity, current_price, new_price, base_value, total;

    // SUB BUTTONS
    $('.quantity-left-minus').click(function(){

        id = $(this).data('id');

        // reduce the quantity
        current_quantity = Number($('#quantity_number' + id).text());

        // price change
        current_price = Number($('#Price' + id).text());
        
        // Calculate base value
        if (current_quantity > 1) {
            base_value = current_price / current_quantity;
        } else {
            base_value = current_price;
        }

        new_price = current_price - base_value;

        // total change
        total = Number($('#cart-value').text());

        // if quantity is 1 then the entire row must be removed
        if (current_quantity === 1) {
            // confirm box from jquery
            if (confirm('Are you sure? You want to remove the product from your cart.')) {
                // remove from UI & update the total
                $('#item-in-cart' + id).remove();
                var updated_total = total - base_value;
                $('#cart-value').text(updated_total);

                // remove from db
                $.ajax({
                    url: "remove_cart_item.php",
                    method: "GET",
                    data: { item_id: id },
                    success: function(response) {
                        // Handle success response
                    },
                    error: function(xhr, status, error) {
                        // Handle error
                    }
                });
            }
        } else {
            new_quantity = current_quantity - 1;

            $.ajax({
                url: "cart_update.php",
                method: "GET",
                data: { item_id: id, quantity: new_quantity }, // Pass id and new_quantity
                success: function(data) {
                    // UPDATE THE UI
                    // update the new quantity
                    $('#quantity_number' + id).text(new_quantity);
                    // updating the price change
                    $('#Price' + id).text(new_price.toFixed(2));
                    // updating the total value of cart
                    $('#cart-value').text(total - base_value);
                },
                error: function() {
                    alert('Some error occurred! Please try again later');
                }
            });
        }
    });

    // ADD BUTTONS
    $('.quantity-right-plus').click(function(){
        // product id
        id = $(this).data('id');

        // increase the quantity
        current_quantity = Number($('#quantity_number' + id).text());
        new_quantity = current_quantity + 1;

        // price change
        current_price = Number($('#Price' + id).text());

        // Calculate base value
        if (current_quantity > 1) {
            base_value = current_price / current_quantity;
        } else {
            base_value = current_price;
        }

        new_price = current_price + base_value;

        // total change
        total = Number($('#cart-value').text());

        $.ajax({
            url: "cart_update.php",
            method: "GET",
            data: { item_id: id, quantity: new_quantity }, // Pass id and new_quantity
            success: function(data) {
                // update the new quantity
                $('#quantity_number' + id).text(new_quantity);
                // updating the price change
                $('#Price' + id).text(new_price.toFixed(2));
                // updating the total value of cart
                $('#cart-value').text(total + base_value);
            },
            error: function() {
                alert('Some error occurred! Please try again later');
            }
        });
    });
});
