var productsData = [
  { productId: 1, name: 'English Ivy', imageUrl: 'images/englishivy-1.jpeg', price: 450 },
  { productId: 2, name: 'Money Plant', imageUrl: 'images/moneyplant-1.jpeg', price: 400 },
  { productId: 3, name: 'Orchids', imageUrl: 'images/orchid-3.jpeg', price: 120 },
  { productId: 4, name: 'Bunny Ear Cactus', imageUrl: 'images/bunnyear-3.jpeg', price: 230 },
  { productId: 5, name: 'Aloe Vera', imageUrl: 'images/aloevera-3.jpeg', price: 120 },
  { productId: 6, name: 'Star Cactus', imageUrl: 'images/starcactus-2.jpeg', price: 170 },
  { productId: 7, name: 'Dumb Cane', imageUrl: 'images/product-thumb-1.jpg', price: 230 },
  { productId: 8, name: 'Dracaena', imageUrl: 'images/Dracaena-1.jpeg', price: 300 },
  { productId: 9, name: 'Sugarcane', imageUrl: 'images/sugarcane-2.jpeg', price: 200 }
];

$(document).ready(function() {
  displayProductsInCart(productsData);
});

function displayProductsInCart(products) {
  var cartTable = $('.cart-table');
  
  // Iterate through each product and generate HTML for it
  products.forEach(function(product) {
    var productHTML = `
    <div class="cart-item border-top border-bottom">
      <div class="row align-items-center">
        <div class="col-lg-4 col-md-3">
          <div class="cart-info d-flex flex-wrap align-items-center">
            <div class="col-lg-5">
              <div class="card-image">
                <img src="${product.imageUrl}" alt="${product.name}" class="img-fluid">
              </div>
            </div>
            <div class="col-lg-7">
              <div class="card-detail ps-3">
                <h5 class="card-title">
                  <a href="#" class="text-decoration-none">${product.name}</a>
                </h5>
                <div class="card-price">
                  <span class="money text-dark">₹ ${product.price}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-7">
          <div class="row d-flex">
            <div class="col-lg-4">
              <div class="input-group product-qty">
                <span class="input-group-btn">
                    <button type="button" class="quantity-left-minus btn btn-light btn-number"  data-type="minus" data-field="">
                      <svg width="16" height="16"><use xlink:href="#minus"></use></svg>
                    </button>
                </span>
                <input type="text" id="quantity" name="quantity" class="form-control input-number text-center" value="1" min="1" max="100">
                <span class="input-group-btn">
                    <button type="button" class="quantity-right-plus btn btn-light btn-number" data-type="plus" data-field="">
                        <svg width="16" height="16"><use xlink:href="#plus"></use></svg>
                    </button>
                </span>
              </div>
            </div>
            <div class="col-lg-8 text-center">
              <div class="total-price">
                <span class="money text-dark">₹ ${product.price}</span>
              </div>
            </div>   
          </div>             
        </div>
        <div class="col-lg-1 col-md-2">
          <div class="cart-remove">
            <a href="#">
              <svg width="32px">
                <use xlink:href="#trash"></use>
              </svg>
            </a>
          </div>
        </div>
      </div>
    </div>
    `;
    
    // Append the product HTML to the cart table
    cartTable.append(productHTML);
  });
}
