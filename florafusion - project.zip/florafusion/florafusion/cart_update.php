<?php
	
	require "database.php";

	session_start();
	 // Perform database connection (assuming it's handled in database.php)
	  $conn = mysqli_connect("localhost", "root", "", "plant5");

	  if (!$conn) {
		  die("Connection failed: " . mysqli_connect_error());
	  }

	$item_id = $_GET['item_id'];
	$new_quantity = $_GET['quantity'];

	// update the increased quantity in the db

	$query ="UPDATE cart SET quantity=$new_quantity WHERE id LIKE $item_id";

	if(mysqli_query($conn,$query)) {
	 	echo "1";
	 }else{
	 	echo "-1";
	 }

?>