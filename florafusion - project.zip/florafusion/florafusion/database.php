<?php

$server = "localhost";
$user = "root";
$passdb = "";
$db = "plant5";
$connect = mysqli_connect( $server, $user, $passdb, $db )or die( "Connection Error" );

?>