<?php
    session_start();

    $conn = mysqli_connect("localhost", "root", "", "plant5");

  if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
        // get the order id from the previous page
        $order_id = $_GET['order_id'];
    

    $cart_value_at_checkout = 0;

    // Properly concatenate the query string
    $query = "SELECT p.ProductID, p.Price, c.quantity FROM cart c INNER JOIN Plants p ON c.ProductID = p.ProductID";

    $result = mysqli_query($conn, $query);

    // Check if the query was executed successfully
    if ($result) {
        // Check if there are any results
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $cart_value_at_checkout += $row['quantity'] * $row['Price'];
            }
        } else {
            echo "No items found in the cart.";
        }
    } else {
        echo "Error executing the query: " . mysqli_error($conn);
    }
?>

<!DOCTYPE html>
<html>
  <head>
    <title>FloraFusion</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta name="description" content="">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/vendor.css">
    <link rel="stylesheet" type="text/css" href="style.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500;600&family=Open+Sans:wght@300;400;500;600;700&family=Over+the+Rainbow&display=swap" rel="stylesheet">
    
    <!-- script
    ================================================== -->
    <script src="js/modernizr.js"></script>
    <script src="https://kit.fontawesome.com/12fd2f4021.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

  
  </head>
  <body data-bs-spy="scroll" data-bs-target="#header-nav">
    <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
      <symbol id="menu" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <title>Menu</title>
        <path fill="currentColor" d="M4 7v2h24V7zm0 8v2h24v-2zm0 8v2h24v-2z"/>
      </symbol>
      <symbol id="close" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <title>Close</title>
        <path fill="currentColor" d="M7.219 5.781L5.78 7.22L14.563 16L5.78 24.781l1.44 1.439L16 17.437l8.781 8.782l1.438-1.438L17.437 16l8.782-8.781L24.78 5.78L16 14.563z"/>
      </symbol>
      <symbol id="search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <title>Search</title>
        <path fill="currentColor" d="M19 3C13.488 3 9 7.488 9 13c0 2.395.84 4.59 2.25 6.313L3.281 27.28l1.439 1.44l7.968-7.969A9.922 9.922 0 0 0 19 23c5.512 0 10-4.488 10-10S24.512 3 19 3zm0 2c4.43 0 8 3.57 8 8s-3.57 8-8 8s-8-3.57-8-8s3.57-8 8-8z" />
      </symbol>
      <symbol id="user" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <title>User</title>
        <path fill="currentColor" d="M16 5c-3.855 0-7 3.145-7 7c0 2.41 1.23 4.55 3.094 5.813C8.527 19.343 6 22.883 6 27h2c0-4.43 3.57-8 8-8s8 3.57 8 8h2c0-4.117-2.527-7.656-6.094-9.188A7.024 7.024 0 0 0 23 12c0-3.855-3.145-7-7-7zm0 2c2.773 0 5 2.227 5 5s-2.227 5-5 5s-5-2.227-5-5s2.227-5 5-5z" />
      </symbol>
      <symbol id="like" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <title>Like</title>
        <path fill="currentColor" d="M9.5 5C5.363 5 2 8.402 2 12.5c0 1.43.648 2.668 1.25 3.563a9.25 9.25 0 0 0 1.219 1.468L15.28 28.375l.719.719l.719-.719L27.53 17.531S30 15.355 30 12.5C30 8.402 26.637 5 22.5 5c-3.434 0-5.645 2.066-6.5 2.938C15.145 7.066 12.934 5 9.5 5zm0 2c2.988 0 5.75 2.906 5.75 2.906l.75.844l.75-.844S19.512 7 22.5 7c3.043 0 5.5 2.496 5.5 5.5c0 1.543-1.875 3.625-1.875 3.625L16 26.25L5.875 16.125s-.484-.465-.969-1.188C4.422 14.216 4 13.274 4 12.5C4 9.496 6.457 7 9.5 7z" />
      </symbol>
      <symbol id="shopping-bag" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <title>Shopping Cart</title>
        <path fill="currentColor" d="M16 3c-2.746 0-5 2.254-5 5v1H6.062L6 9.938l-1 18L4.937 29h22.125L27 27.937l-1-18L25.937 9H21V8c0-2.746-2.254-5-5-5zm0 2a3 3 0 0 1 3 3v1h-6V8a3 3 0 0 1 3-3zm-8.063 6H11v3h2v-3h6v3h2v-3h3.063l.875 16H7.063z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="plus" viewBox="0 0 24 24">
        <path fill="currentColor" d="M19 11h-6V5a1 1 0 0 0-2 0v6H5a1 1 0 0 0 0 2h6v6a1 1 0 0 0 2 0v-6h6a1 1 0 0 0 0-2Z"/>
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="minus" viewBox="0 0 24 24">
        <path fill="currentColor" d="M19 11H5a1 1 0 0 0 0 2h14a1 1 0 0 0 0-2Z"/>
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="check" viewBox="0 0 24 24">
        <path fill="currentColor" d="M18.71 7.21a1 1 0 0 0-1.42 0l-7.45 7.46l-3.13-3.14A1 1 0 1 0 5.29 13l3.84 3.84a1 1 0 0 0 1.42 0l8.16-8.16a1 1 0 0 0 0-1.47Z"/>
      </symbol>
    </svg>

    <header id="header-wrap" class="align-items-center position-fixed bg-white px-3">

      <nav class="navbar navbar-expand-lg">

        <div class="container-fluid">
          <div class="col-md-3">
            <div class="main-logo">
              <a href="home.html">
                <img src="images/main-logo.png" alt="main-logo">
              </a>
            </div>
          </div>

          <button class="navbar-toggler text-white" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation"><svg class="menu" width="24" height="24"><use xlink:href="#menu" /></svg></button>
          
          <!-- off canvas -->
          <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            
            <div class="offcanvas-header">
              <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
              <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body justify-content-end">

              <div class="col-md-6">
                <ul id="header-nav" class="navbar-nav justify-content-center d-flex flex-grow-1 list-unstyled text-uppercase">
                  <li class="nav-item pe-5">
                    <a href="home.html" class="nav-link">Home</a>
                  </li>
                  <li class="nav-item pe-5">
                    <a href="about.html" class="nav-link">About</a>
                  </li>
                  <li class="nav-item pe-5">
                    <a href="shop.php" class="nav-link">Shop</a>
                  </li>
                  <li class="nav-item pe-5">
                    <a href="services.html" class="nav-link">Services</a>
                  </li>
                  <li class="nav-item pe-5">
                    <a href="blog.html" class="nav-link">Events</a>
                  </li>
                  <li class="nav-item pe-5">
                    <a href="contact.html" class="nav-link">Contact</a>
              </div>

            </div>
          </div>
          <!-- / off canvas -->

          <div class="col-md-3">
            <div class="right-block d-flex justify-content-end">
              <div id="search-bar" class="border-right me-2 pe-1">
               
              </div>
              <div class="user-items d-flex gap-3">
                <a href="userlogin.php" title="user">
                  <svg class="user" width="24" height="24"><use xlink:href="#user" /></svg>
                </a>
                
                <a href="cart.php" title="bag">
                  <svg class="shopping-bag" width="24" height="24"><use xlink:href="#shopping-bag" /></svg>
                </a>
                <a href="logoutuser.php" title="Logout">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" id="IconChangeColor" height="22" width="24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8m4-9-4-4m4 4-4 4m4-4H9" id="mainIconPathAttribute"></path></svg>
              </div>
            </div>
          </div>

        </div>
      </nav>
    </header>
    
    <section class="hero-section position-relative bg-light-blue py-5">
      <div class="hero-content">
        <div class="container">
          <div class="row py-5 my-5">
            <div class="text-center py-5 mt-5 no-padding-bottom">
              <h1 class="display-2 text-uppercase text-dark">Discounts</h1>
              <div class="breadcrumbs">
                <span class="item">
                  <a href="home.html">Home</a>
                </span>
                 </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section class="shopify-cart checkout-wrap py-5">
    <div class="container">
            <div class="row d-flex flex-wrap">
                <div class="col-lg-6 apply-coupon">
                    <div style="text-align: center;">
                        <h2 class="display-7 text-uppercase text-dark pb-4">CART SUBTOTAL : ₹ <span id="total_before_disc"><?php echo $cart_value_at_checkout; ?></span></h2>
                        <p><i>Select a coupon to avail the discount... <i class="fas fa-tags"></i></i></p>
                        <div class="billing-details">
                        <form id="discount-form">
                            <label style="font-family: 'Times new Roman';font-size: 1.6rem;" for="coupon">Choose a coupon:</label>
                            <select name="coupon" id="coupon">
                                <option value="NONE">NONE</option>
                                <option value="MAX50">MAX50</option>
                                <option value="15PER">15PER</option>
                                <option value="CELBRT150">CELBRT150</option>
                                <option value="GRAB25">GRAB25</option>
                                <option value="TRYNEW">TRYNEW</option>
                            </select>
                            <br><br>
                          </form>
                            <button type="button" id="discount-btn">APPLY</button>
                            <h4 id="applied_disc"></h4>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="total-price select-coupon">
                        <table cellspacing="0" class="table">
                            <tbody>
                                <?php
                                $conn = mysqli_connect("localhost", "root", "", "plant5");

                                if (!$conn) {
                                    die("Connection failed: " . mysqli_connect_error());
                                }

                                $query = "SELECT * FROM coupon";
                                $result = mysqli_query($conn, $query);

                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo '<tr class="coupon-details">
                                            <th style="font-size: 20px;">'.$row['coupon_code'].'</th>
                                            <td>
                                                <div class="details">
                                                    <h3 class="display-12 text-uppercase text-dark pb-4">'.$row['coupon_type'].'</h3>';
                                    if ($row['coupon_type'] == 'FLAT OFF') {
                                        echo '<h2>Rs. '.$row['coupon_value'].' ( <span id="min-cart-val"><i style="font-size: 20px; color: grey;">Minimum Cart Value : Rs. '.$row['cart_min_value'].'</i></span> )</h2>';
                                    } else {
                                        echo '<h2>'.$row['coupon_value'].'% ( <span id="min-cart-val"><i style="font-size: 20px; color: grey;">Minimum Cart Value : Rs. '.$row['cart_min_value'].'</i></span> )</h2>';
                                    }
                                    echo '      </div>
                                            </td>
                                        </tr>';
                                }
                                ?>
                                <!-- so that we can retrieve the value of order id on the next page -->
                                <input type="hidden" name="order_id" value="<?php echo $order_id; ?>" id="order_id">
                            </tbody>
                        </table>
                    </div>
                    <div style="text-align: center;">
                        <a href="checkout.php?order_id=<?php echo $order_id; ?>" class="btn btn-dark btn-medium text-uppercase btn-rounded-none" style="margin-top: 25px;" id="go-to-address-page">Proceed</a>
                    </div>
                </div>
            </div>
    </div>
</section>

    <footer class="bg-light-green position-relative">
      <div class="pattern-overlay6">
        <img src="images/pattern-overlay6.png" alt="pattern" class="position-absolute">
      </div>
      <div class="container">
        <div class="row py-5">
          <div class="col-md-3">
            <div class="main-logo">
              <img src="images/main-logo.png" logo>
            </div>
          </div>
          <div class="col-md-3">
            <h5 class="widget-title pb-3">Shop</h5>
            <ul class="nav flex-column">
              <li class="nav-item mb-2">
                <a href="shop.php" class="nav-link p-0 text-muted">All Collections</a>
              </li>
              <li class="nav-item mb-2">
                <a href="shop.php" class="nav-link p-0 text-muted">Collection</a>
              </li>
              <li class="nav-item mb-2">
                <a href="shop.php" class="nav-link p-0 text-muted">Product Page</a>
              </li>
            </ul>
          </div>
          <div class="col-md-3">
            <h5 class="widget-title pb-3">Follow Us</h5>
            <ul class="nav flex-column">
              <li class="nav-item mb-2">
                <a href="#" class="nav-link p-0 text-muted">Instagram</a>
              </li>
              <li class="nav-item mb-2">
                <a href="#" class="nav-link p-0 text-muted">Facebook</a>
              </li>
              <li class="nav-item mb-2">
                <a href="#" class="nav-link p-0 text-muted">Twitter </a>
              </li>
              <li class="nav-item mb-2">
                <a href="#" class="nav-link p-0 text-muted">Pinterest</a>
              </li>
              <li class="nav-item mb-2">
                <a href="#" class="nav-link p-0 text-muted">Youtube</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="footer-bottom py-4 border-top">
        <div class="container">
          <div class="row d-flex justify-content-end">
            <div class="col-md-6">
             
            </div>
            <div class="col-md-6 text-end">
              
            </div>
          </div>
        </div>
      </div>
    </footer>

    <script src="js/jquery-1.11.0.min.js"></script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script type="text/javascript" src="js/plugins.js"></script>
    <script type="text/javascript" src="js/script.js"></script>
    
    <script type="text/javascript" src="js/coupon.js"></script>
    <script type="text/javascript" src="js/final_coupon.js"></script>
  

</body>
</html>