<?php
session_start();
include("database.php"); // Assuming database.php contains your database connection code

// Initialize an array to store validation errors
$errors = [];
$success_message = ""; // Initialize success message variable

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    // Check if the form fields are set and not empty
    $tempfirstname = isset($_POST['firstname']) ? trim($_POST['firstname']) : '';
    $templastname = isset($_POST['lastname']) ? trim($_POST['lastname']) : '';
    $tempemail = isset($_POST['email']) ? trim($_POST['email']) : '';
    $tempphoneno = isset($_POST['phoneno']) ? trim($_POST['phoneno']) : '';
    $tempevent = isset($_POST['event']) ? $_POST['event'] : [];

    // Check if at least one event is selected
    
    // If there are no validation errors, proceed with inserting data into the database
    if (empty($errors)) {
        $tempevent = implode(", ", $tempevent);
        $sql = "INSERT INTO event (firstname, lastname, email, phoneno, event) 
                VALUES ('$tempfirstname', '$templastname', '$tempemail', '$tempphoneno', '$tempevent')";

        if (mysqli_query($connect, $sql)) {
            // Set success message if registration is successful
            $success_message = "Registered successfully!";
            header("refresh:1;url=blog.html");
        } else {
            echo "<strong>New User Adding Failure. Try Again</strong><br> Error Details: " . mysqli_error($connect);
        }
        mysqli_close($connect);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Event</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="register-container">
        <form name="register" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" onsubmit="return validateForm()">
            <legend><center><h2 style="padding-top: 5px;">&nbsp; EVENT REGISTRATION FORM</h2></center></legend>
            <?php
            if (!empty($errors)) {
                echo "<div>";
                foreach ($errors as $error) {
                    echo "<strong>Error: $error</strong><br>";
                }
                echo "</div>";
            }
            ?>
            <div>
                <label for="firstname">First Name : <span style="color: #ff0000;">*</span></label>
                <input type="text" name="firstname" id="firstname" placeholder="First Name" required>
            </div>
            <div>
                <label for="lastname">Last Name : <span style="color: #ff0000;">*</span></label>
                <input type="text" name="lastname" id="lastname" placeholder="Last Name" required>
            </div>
            <div>
                <label for="email">Email : <span style="color: #ff0000;">*</span></label>
                <input type="email" name="email" id="email" placeholder="abc@gmail.com" required>
            </div>
            <div>
                <label for="phoneno">Phone Number : <span style="color: #ff0000;">*</span></label>
                <input type="tel" name="phoneno" id="phoneno" placeholder="**********" maxlength="10" pattern="[0-9]{10}" required>
            </div>
            <br>
            <div>
                <label for="event">Events : <span style="color: #ff0000;">*</span></label><br>
                <input type="checkbox" name="event[]" id="cleanup" value="Community Cleanup">
                <label for="cleanup"> COMMUNITY GARDEN CLEANUP</label><br>
                <input type="checkbox" name="event[]" id="herb" value="Herb Garden">
                <label for="herb"> HERB GARDEN WORKSHOP</label><br>
                <input type="checkbox" name="event[]" id="butterfly" value="Butterfly Garden">
                <label for="butterfly"> BUTTERFLY GARDEN INSTALLATION</label><br>
                <input type="checkbox" name="event[]" id="native" value="Native Restoration">
                <label for="native">  NATIVE PLANT RESTORATION PROJECT</label><br>
                <input type="checkbox" name="event[]" id="plantation" value="Tree Plantation">
                <label for="plantation"> TREE PLANTATION DAY</label><br>
                <input type="checkbox" name="event[]" id="fall" value="Fall Festival">
                <label for="fall"> FALL PLANTING FESTIVAL</label><br>
            </div><br>

            <center><button type="submit" name="register">Book</button></center>
        </form>
    </div>

    <!-- Display success message if set -->
    <?php
    if (!empty($success_message)) {
        echo "<script>alert('$success_message');</script>";
    }
    ?>

    <script>
        function validateForm() {
            var checkboxes = document.querySelectorAll('input[name="event[]"]');
            var checked = false;
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].checked) {
                    checked = true;
                    break;
                }
            }
            if (!checked) {
                alert("Please select at least one event.");
                return false; // Prevent form submission
            }
            return true; // Allow form submission
        }
    </script>
</body>
</html>
