<?php
// Database connection parameters
$servername = "localhost"; // Change this if your MySQL server is hosted elsewhere
$username = "root";
$password = "";
$database = "plant5";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$firstname = $_POST['firstname'];
$email = $_POST['email'];
$phoneno = $_POST['phoneno'];
$subject = $_POST['subject'];
$message = $_POST['message'];

// SQL query to insert data into the contact table
$sql = "INSERT INTO faq(firstname, email, phoneno, subject, message) VALUES ('$firstname', '$email', '$phoneno', '$subject', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "Your response has been submitted";
    header("refresh:3;url=faq.html");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
