$(document).on('click', '#discount-btn', function() {
    var coupon_code = $('#coupon').val();
    var total_before_disc = $('#total_before_disc').text();

    $.ajax({
        url: "apply_coupon.php",
        method: "GET",
        data: {
            coupon_code: coupon_code,
            total_before_disc: total_before_disc
        },
        success: function(data) {
            $('#applied_disc').text(data);
        }
    });
});