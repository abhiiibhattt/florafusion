<?php
session_start();
?>

<?php
$x = $_POST[ "email" ];
$y = $_POST[ "pswd" ];

include( "database.php" );
//searching login id and password entered in $x & $y
$sql = "select * from users where Email='" . $x . "' and Pswd='" . $y . "'";

$result = mysqli_query( $connect, $sql );

if ( $result->num_rows > 0 )

//session create
{
	if ( $row = $result->fetch_assoc() ) {
		$_SESSION[ "emailid" ] = $row[ "Email" ];
		$_SESSION[ "pswd" ] = $row[ "Pswd" ];

	}
	//redirecting to welcome faculty page
	header( 'Location:home.html' );
} else {
	//error message if SQL query fails
	echo "<h3><span style='color:red; '>Invalid Email Id & Password. Page Will redirect to Login Page after 3 seconds </span></h3>";
	header( "refresh:3;url=userlogin.php");
}
$connect->close();

?>