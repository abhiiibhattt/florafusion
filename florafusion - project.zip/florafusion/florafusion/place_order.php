<?php

$conn = mysqli_connect("localhost", "root", "", "plant5");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

// insert into order_track table in db

$order_id = uniqid();

date_default_timezone_set("Asia/Kolkata");
$order_date = date("Y/m/d h:i:sa");

$total = 0;

$query = "SELECT p.ProductID, p.Price, c.quantity FROM cart c INNER JOIN Plants p ON c.ProductID = p.ProductID";

$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {
    $total += $row['quantity'] * $row['Price'];
}

// query to insert into the table

$query1 = "INSERT INTO `order_track` (`id`, `order_date`, `order_total`, `coupon`, `address`, `payment_mode`, `payment_status`, `order_status`) VALUES ('$order_id', '$order_date', '$total', '', '0', '', 'Pending', 'Not purchased')";

if (mysqli_query($conn, $query1)) {

    // populate the order_details table with the food_items ordered

    $result1 = mysqli_query($conn, $query);

    while ($row1 = mysqli_fetch_assoc($result1)) {

        $product_id = $row1['ProductID'];
        $quantity = $row1['quantity'];

        $query2 = "INSERT INTO order_details VALUES(NULL,'$order_id',$product_id,$quantity)";

        mysqli_query($conn, $query2);
    }

    // redirect to coupons page
    header('Location:discount.php?order_id=' . $order_id);
} else {
    echo "Order not placed";
}

?>
