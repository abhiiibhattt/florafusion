<?php

session_start();

    // Check if the form has been submitted
    if(isset($_POST['submit'])) {
        $Fname = $_POST['firstname'] ?? '';
        $Lname = $_POST['lastname'] ?? '';
        $Country = $_POST['country'] ?? ''; // Corrected to use the 'name' attribute
        $Address = $_POST['address'] ?? '';
        $City = $_POST['city'] ?? '';
        $State = $_POST['state'] ?? ''; // Corrected to use the 'name' attribute
        $Zip = $_POST['zip'] ?? '';
        $Phone = $_POST['phone'] ?? '';
        $Email = $_POST['email'] ?? '';
        $amount = $_SESSION['total_after_disc']*100?? ''; // Convert to paise

        // Your processing logic here
        // Database connection
        $servername = "localhost";
        $username = "root"; 
        $password = ""; 
        $dbname = "plant5"; 
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Insert data into table
        $sql = "INSERT INTO checkout (firstname, lastname, country, address, city, state, zip, phoneno, email)
        VALUES ('$Fname', '$Lname', '$Country', '$Address', '$City', '$State', '$Zip', '$Phone', '$Email')";

        if ($conn->query($sql) === TRUE) {
            echo "";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    }
    
?>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
var options = {
    "key": "rzp_test_fSeISm6HJGUfu4",
    "amount": "<?php echo $amount; ?>",
    "currency": "INR",
    "name": "FloraFusion",
    "description": "Test Transaction",
    "id": "<?php echo 'OID' . rand(10,100).'END'; ?>",
    "prefill": {
        "name": "<?php echo $Fname . ' ' . $Lname; ?>",
        "email": "<?php echo $Email; ?>",
        "contact": "<?php echo $Phone; ?>"
    },
    "notes": {
        "address": "<?php echo $Address; ?>",
        "city": "<?php echo $City; ?>",
        "state": "<?php echo $State; ?>",
        "zip_code": "<?php echo $Zip; ?>",
        "country": "<?php echo $Country; ?>"
    },
    "handler": function (response){
        // handle the response
        var paymentId = response.razorpay_payment_id;
        var url = "/verify_payment.php"; // replace with your verification URL
        var xhr = new XMLHttpRequest();
        xhr.open("POST", url, true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // redirect to the appointments page after the payment is verified
                window.location.href = 'https://localhost/project/florafusion/home.html';
            }
        };
        var data = "payment_id=" + paymentId;
        xhr.send(data);
    }
    //"redirect_url": "https://localhost/project/florafusion/payment_successful.html"
};
try {
    var rzp1 = new Razorpay(options);
    rzp1.open();
} catch (error) {
    console.log(error);
    alert("An error occurred: " + error.message);
}
</script>