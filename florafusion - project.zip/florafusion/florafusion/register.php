<?php
session_start();
include("database.php"); // Assuming database.php contains your database connection code
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="register-container">
  <form name="register" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
    <legend>
      <center><h2 style="padding-top: 5px;">&nbsp; Register</h2></center>
    </legend>
    <div>
      <label for="Username">Username : <span style="color: #ff0000;">*</span></label>
      <input type="text" name="username" id="username" placeholder="Username" required>
    </div>
    <div>
      <label for="Email">Email : <span style="color: #ff0000;">*</span></label>
      <input type="email" name="email" id="email" placeholder="abc@gmail.com" required>
    </div>
    <div>
      <label for="Password">Password : <span style="color: #ff0000;">*</span></label>
      <input type="password" name="pswd" id="pswd" placeholder="Password" required>
    </div>
    <center><button type="submit" name="register">Register</button></center>
  </form>
  <p>Already have an account? <a href="userlogin.php">Login here</a></p>
</div>
<?php
if (isset($_POST['register'])) {
  $tempusername = $_POST['username'];
  $tempemail = $_POST['email'];
  $temppswd = $_POST['pswd'];
  
  // adding new user
  $sql = "INSERT INTO users (username, email, pswd) VALUES ('$tempusername', '$tempemail', '$temppswd')";

  if (mysqli_query($connect, $sql)) {
    echo "<br>
    <br><br>";
    echo "<script>alert('Registration successful');</script>";
    header("refresh:1;url=userlogin.php");
  } else {
    // error message if SQL query Fails
    echo "<br><Strong>New User Adding Failure. Try Again</strong><br> Error Details: " . mysqli_error($connect);
  }
  // close the connection
  mysqli_close($connect);
}
?>
</body>
</html>
