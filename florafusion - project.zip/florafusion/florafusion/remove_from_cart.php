<?php
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if productId is set
    if (isset($_POST["productId"])) {
        // Sanitize input
        $productId = $_POST["productId"];

        // Remove the product from the cart in the database
        $conn = mysqli_connect("localhost", "root", "", "plant5");

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $query = "DELETE FROM cart WHERE ProductID = $productId";

        if (mysqli_query($conn, $query)) {
            echo "Product removed successfully";
        } else {
            echo "Error removing product: " . mysqli_error($conn);
        }

        mysqli_close($conn);
    } else {
        echo "Product ID not provided";
    }
} else {
    echo "Invalid request method";
}
?>
