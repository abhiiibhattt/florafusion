<?php
// PHP code to fetch product information from the database
$conn = mysqli_connect("localhost", "root", "", "plant5");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the productId is set and valid
if (isset($_POST['productId'])) {
    $productId = $_POST['productId'];
    
    // Prepare and execute the SQL query to remove the product from the cart table
    $sql = "DELETE FROM cart WHERE ProductID = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$productId]);
    
    // Check if the product was successfully removed
    if ($stmt->rowCount() > 0) {
        // Send a success response
        echo "Product removed successfully";
    } else {
        // Send an error response
        echo "Failed to remove product";
    }
} else {
    // Send an error response if productId is not set
    echo "Product ID is not set";
}
?>
