// cart.js
let cart = [];

document.querySelectorAll('.add-to-cart').forEach(button => {
  button.addEventListener('click', function() {
    let productId = this.dataset.productId;
    addToCart(productId);
  });
});

function addToCart(productId) {
  // In a real application, you would likely have a list of products somewhere,
  // and you would find the product details based on the product ID.
  // For simplicity, we'll just use a dummy product here.
  let product = {
    id: productId,
    name: 'Product Name',
    description: 'Product Description'
  };

  cart.push(product);

  // Save the cart to local storage so it persists across page loads
  localStorage.setItem('cart', JSON.stringify(cart));
}sa