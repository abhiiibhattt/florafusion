<?php
session_start();
include("database.php"); // Assuming database.php contains your database connection code

// Initialize an array to store validation errors
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    // Check if the form fields are set and not empty
    $tempfirstname = isset($_POST['firstname']) ? trim($_POST['firstname']) : '';
    $templastname = isset($_POST['lastname']) ? trim($_POST['lastname']) : '';
    $tempemail = isset($_POST['email']) ? trim($_POST['email']) : '';
    $tempphoneno = isset($_POST['phoneno']) ? trim($_POST['phoneno']) : '';
    $tempservice = isset($_POST['service']) ? $_POST['service'] : [];
    $tempdate = isset($_POST['date']) ? $_POST['date'] : '';
    $temptime = isset($_POST['time']) ? $_POST['time'] : '';

    // Validate if at least one service is selected
    

    // If there are no validation errors, proceed with inserting data into the database
    if (empty($errors)) {
        $tempserviceStr = implode(", ", $tempservice);
        $sql = "INSERT INTO services (firstname, lastname, email, phoneno, service, date, time) 
                VALUES ('$tempfirstname', '$templastname', '$tempemail', '$tempphoneno', '$tempserviceStr', '$tempdate', '$temptime')";

        if (mysqli_query($connect, $sql)) {
            echo "<script>alert('Booking successful'); </script>";
            header("refresh:1;url=services.html");
            exit();
        } else {
            echo "<strong> Try Again</strong><br> Error Details: " . mysqli_error($connect);
        }
        mysqli_close($connect);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Service</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="service-container">
        <form name="register" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" onsubmit="return validate()">
            <legend><center><h2 style="padding-top: 5px;">&nbsp; BOOK SERVICE NOW! </h2></center></legend>
            <?php
            if (!empty($errors)) {
                echo "<div>";
                foreach ($errors as $error) {
                    echo "<strong>Error: $error</strong><br>";
                }
                echo "</div>";
            }
            ?>
            <div>
                <label for="firstname"><b>First Name : </b><span style="color: #ff0000;">*</span></label>
                <input type="text" name="firstname" id="firstname" placeholder="First Name" required>
            </div>
            <div>
                <label for="lastname"><b>Last Name : </b><span style="color: #ff0000;">*</span></label>
                <input type="text" name="lastname" id="lastname" placeholder="Last Name" required>
            </div>
            <div>
                <label for="email"><b>Email : </b><span style="color: #ff0000;">*</span></label>
                <input type="email" name="email" id="email" placeholder="abc@gmail.com" required>
            </div>
            <div>
                <label for="phoneno"><b>Phone Number : </b><span style="color: #ff0000;">*</span></label>
                <input type="tel" name="phoneno" id="phoneno" placeholder="" maxlength="10" pattern="[0-9]{10}" required>
            </div>
            <br>
            <div>
                <label for="address"><b>Address : </b><span style="color: #ff0000;">*</span></label><br>
                <textarea name="address" id="address" rows="4" cols="40" required></textarea>
            </div>

            <div>
                <label for="service"><b>Service : </b><span style="color: #ff0000;">*</span></label><br>
                <input type="checkbox" name="service[]" id="pest" value="Pest Management">
                <label for="pest"> <b>Pest Management</b></label><br>
                <div style="margin-left: 20px;">
                    <input type="radio" name="service[]" id="pest" value="Pest Management">
                    <label for="pest"> Kalyan Shetty</label><br>
                    <input type="radio" name="service[]" id="pest" value="Pest Management">
                    <label for="pest"> Rahul Sobith</label><br>
                    <input type="radio" name="service[]" id="pest" value="Pest Management">
                    <label for="pest"> Martha S</label><br>
                    <input type="radio" name="service[]" id="pest" value="Pest Management">
                    <label for="pest"> Surya Prakash</label><br>
                </div><br>
                <input type="checkbox" name="service[]" id="lawn" value="Lawn Mowing">
                <label for="lawn"> <b>Lawn Mowing</b></label><br>
                <div style="margin-left: 20px;">
                    <input type="radio" name="service[]" id="pest" value="Pest Management">
                    <label for="pest"> Martha S</label><br>
                </div><br>
                <input type="checkbox" name="service[]" id="pond" value="Pond Gardening">
                <label for="pond"> <b>Indoor Gardening</b></label><br>
                <div style="margin-left: 20px;">
                    <input type="radio" name="service[]" id="pest" value="Pest Management">
                    <label for="pest"> Rakesh Gowda</label><br>
                    <input type="radio" name="service[]" id="pest" value="Pest Management">
                    <label for="pest"> Susan Joan</label><br>
                </div>
            </div><br>

            <div>
                <label for="date"><b>Date :</b> <span style="color: #ff0000;">*</span></label>
                <input type="date" name="date" id="date" min="<?php echo date('Y-m-d'); ?>" required>
            </div><br>
            <div>
                <label for="time"><b>Time : </b><span style="color: #ff0000;">*</span></label>
                <input type="time" name="time" id="time" min="<?php echo date('H:i'); ?>" required>
            </div><br>
            
            <center><button type="submit" name="register"><b>Book</b></button></center>
           
        </form>
        
    </div>
<script>
function validate() {
    // Get all checkboxes with name "service[]"
    let checkboxes = document.querySelectorAll('input[name="service[]"]');
    let checked = false;

    // Check if at least one checkbox is checked
    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            checked = true;
        }
    });

    // Display error message if no checkbox is checked
    if (!checked) {
        alert("Select at least one service");
        return false; // Prevent form submission
    }

    return true; // Allow form submission
}

// Get the current time
var currentTime = new Date();
var currentHour = currentTime.getHours();
var currentMinute = currentTime.getMinutes();

// Format the current time into HH:mm format
var formattedTime = (currentHour < 10 ? '0' : '') + currentHour + ':' + (currentMinute < 10 ? '0' : '') + currentMinute;

// Set the minimum time for the input field
document.getElementById('time').min = formattedTime;
</script>
</body>
</html>