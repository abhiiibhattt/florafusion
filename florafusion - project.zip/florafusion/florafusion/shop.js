$(document).ready(function() {
    $('.add-to-cart').click(function() {
        var productId = $(this).data('product-id');
        addToCart(productId);
    });
});

function addToCart(productId) {
    // Send an AJAX request to your server to add the product to the cart
    $.ajax({
        url: 'cart.php', // Replace with the actual endpoint to handle adding to cart
        method: 'POST',
        data: { productId: productId },
        success: function(response) {
            // Handle the response from the server
            alert('Product added to cart!');
        },
        error: function(xhr, status, error) {
            // Handle errors
            console.error(error);
        }
    });
}
