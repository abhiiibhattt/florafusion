<?php
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if productId and quantity are set
    if (isset($_POST["productId"]) && isset($_POST["quantity"])) {
        // Sanitize input
        $productId = $_POST["productId"];
        $quantity = $_POST["quantity"];

        // Update the quantity in the database
        $conn = mysqli_connect("localhost", "root", "", "plant5");

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $query = "UPDATE cart SET quantity = $quantity WHERE ProductID = $productId";

        if (mysqli_query($conn, $query)) {
            echo "Quantity updated successfully";
        } else {
            echo "Error updating quantity: " . mysqli_error($conn);
        }

        mysqli_close($conn);
    } else {
        echo "Product ID and quantity not provided";
    }
} else {
    echo "Invalid request method";
}
?>
