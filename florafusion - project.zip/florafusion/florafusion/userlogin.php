<?php
// Start the session
session_start();

// Define a variable to check if login is successful
$login_successful = false;

// Your login logic here...
// For example, if you have a login check, you might set $login_successful to true if login is successful

// For demonstration purposes, let's assume login is successful
$login_successful = true;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Login</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="login-container">
  <form name="userlogin" action="loginlinkuser.php" method="POST">
    <legend>
      <h2 style="text-align: center; padding-top: 5px;">User Login</h2>
    </legend>
    <label>Email:</label>
    <input type="text" name="email" placeholder="abc@gmail.com" required data-validation-required-message="Please enter your Email.">
    <label>Password:</label> 
    <input type="password" name="pswd" placeholder="Password" required data-validation-required-message="Please enter your Password.">
    <div style="text-align: center;">
      <center><button type="submit">Login</button>
      <button type="reset" style="background-color: red;">Reset</button></center>
    </div>
  </form>
  <p>Don't have an account? <a href="register.php">Register here</a></p>
<?php
// If login is successful, handle it here by setting session variables
if ($login_successful) {
    $_SESSION["loggedin"] = true;
}
?>
</div>
</body>
</html>
